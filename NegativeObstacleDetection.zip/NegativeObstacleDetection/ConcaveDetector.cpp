#include "ConcaveDetector.h"

using namespace std;

ConcaveDetector::ConcaveDetector()
{
	m_hdldata = NULL;
	m_cloud = NULL;
	m_cloud_saved = NULL;
	m_point = NULL;
	m_point_inbox = NULL;
	m_cloud = NULL;
	m_cos_raw = NULL;
	m_sin_raw = NULL;
}

ConcaveDetector::~ConcaveDetector()
{
	if (m_hdldata)
	{
		fclose(m_hdldata);
		m_hdldata = NULL;
	}
	if (m_cloud)
	{
		delete[] m_cloud;
		m_cloud = NULL;
	}
	if (m_cloud_saved)
	{
		delete[] m_cloud_saved;
		m_cloud_saved = NULL;
	}
	if (m_point) {
		delete[] m_point;
		m_point = NULL;
	}
	if (m_point_inbox){
		delete[] m_point_inbox;
		m_point_inbox = NULL;
	}
	if (m_cos_raw)
	{
		delete[] m_cos_raw;
		m_cos_raw = NULL;
	}
	if (m_sin_raw)
	{
		delete[] m_sin_raw;
		m_sin_raw = NULL;
	}
}

bool ConcaveDetector::Initialize(const char* hdlfilepath){
	m_cloud       = new LPoint_t[HDL_MAX_POINT_NUMBER];
	m_cloud_saved = new PointSave_t[HDL_MAX_POINT_NUMBER];
	m_point       = new Point_laser_t[HDL_LASER_NUMBER];
	m_point_inbox = new Point_laser_t[HDL_LASER_NUMBER];
	m_cos_raw = new float[ANGLE_NUM];             // ANGLE_NUM = 36000
	m_sin_raw = new float[ANGLE_NUM];
	m_cloud_count = 0;
	int temp[] = { 39, 40, 43, 44, 33, 34, 37, 38, 41, 42,
		47, 48, 51, 52, 55, 56, 45, 46, 49, 50,
		53, 54, 59, 60, 63, 64, 35, 36, 57, 58,
		61, 62, 7, 8, 11, 12, 1, 2, 5, 6,
		9, 10, 15, 16, 19, 20, 23, 24, 13, 14,
		17, 18, 21, 22, 27, 28, 31, 32, 3, 4,
		25, 26, 29, 30
	};
	for (int i = 0; i < HDL_LASER_NUMBER; i++){
		m_laser_index[i] = temp[i];
	}

	if (!load_laser_info("new_xml.txt")) return false;
	if ((m_hdldata = fopen(hdlfilepath, "rb")) == NULL)
	{
		cout << "read hdl file " << hdlfilepath << " error!" << endl;
		return false;
	}

	InitLocalGrids();
	return true;
}

bool ConcaveDetector::load_laser_info(const char* data_path)
{
	//the dat file is converted from db.xml, only have the array info
	//used parse_xml_db solution to convert xml to dat file
	ifstream fdb(data_path);
	if (!fdb)
	{
		cout << "read laser info file error!" << endl;
		return false;
	}

	for (int i = 0; i < HDL_LASER_NUMBER; i++)
	{
		fdb >> m_rot[i] >> m_vert[i] >> m_dist[i] >> m_z_off[i] >> m_x_off[i] >> m_min_i[i] >> m_max_i[i] >> m_distX[i] >> m_distY[i] >> m_f_d[i] >> m_f_s[i];
	}
	fdb.close();

	//regulate unit to mm
	for (int i = 0; i < HDL_LASER_NUMBER; i++)
	{
		m_dist[i] *= 10;
		m_z_off[i] *= 10;
		m_x_off[i] *= 10;
		m_distX[i] *= 10;
		m_distY[i] *= 10;
	}

	//pre-processing sin, cos array
	for (int i = 0; i < HDL_LASER_NUMBER; i++)
	{
		m_cos_rot[i] = (float)cos(m_rot[i] / 180.0f * M_PI);
		m_sin_rot[i] = (float)sin(m_rot[i] / 180.0f * M_PI);
		m_cos_vert[i] = (float)cos(m_vert[i] / 180.0f * M_PI);
		m_sin_vert[i] = (float)sin(m_vert[i] / 180.0f * M_PI);
	}

	for (int i = 0; i < ANGLE_NUM; i++)
	{
		m_cos_raw[i] = (float)cos(i / 18000.0f * M_PI);
		m_sin_raw[i] = (float)sin(i / 18000.0f * M_PI);
	}

	return true;
}

void ConcaveDetector::InitLocalGrids(){
	for (int i = 1; i < local_grid_height; i++) {
		for (int j = 1; j < local_grid_width; j++)
		{
			_localCoordinateSys[i][j].setXValue(0);
			_localCoordinateSys[i][j].setYValue(0);
			_localCoordinateSys[i][j].setMaxHeight(-10000);
			_localCoordinateSys[i][j].setMinHeight(+10000);
			_localCoordinateSys[i][j].setDotCount(0);
			_localCoordinateSys[i][j].setPForObstacle(0.5);			// initialize the empty cell with 0.5
			_localCoordinateSys[i][j].setPForNegativeObstacle(0.5);
		}
	}
}

bool ConcaveDetector::UpdateLocalGrids(){
	InitLocalGrids();
	for (int i = 0; i < m_cloud_count; i++) {
		LPoint_t *tmp_pt = &m_cloud[i]; // unit is mm
		if (tmp_pt->x < 50000 && tmp_pt->x > -50000 && tmp_pt->y < 50000 && tmp_pt->y >-50000)
		{
			// calculate the grid that it belongs to and update localCoordinateSys[][]
			int col = (int)floor(tmp_pt->x / 200+250);
			int row = (int)floor(tmp_pt->y / 200+250);
			_localCoordinateSys[row][col]._dotCount++;
			// update the maxheight and minheight of the grid
			if (tmp_pt->z > _localCoordinateSys[row][col]._maxHeight)
				_localCoordinateSys[row][col]._maxHeight = tmp_pt->z;
			if (tmp_pt->z < _localCoordinateSys[row][col]._minHeight)
				_localCoordinateSys[row][col]._minHeight = tmp_pt->z;
		}
	}
	cout << "There are " << m_cloud_count << " hdl points in detect box!" << endl;
	// traverse all the cloud point and get the probability of obstacle and part of probability of negative obstacle
	int qt=0;
	for (int row = 0; row < local_grid_width; row++)
	{
		for (int col = 0; col < local_grid_height; col++)
		{
			if (_localCoordinateSys[row][col].getDotCount() > 1)
			{
				// update pForObstacle
				if (_localCoordinateSys[row][col].getMaxHeight() - _localCoordinateSys[row][col].getMinHeight() < obj_height_thr)
					_localCoordinateSys[row][col]._pForObstacle = 0.3;
				else {
					_localCoordinateSys[row][col]._pForObstacle = 0.8;
					qt++;
				}
				//featurePoint.push_back(Point2f((col - 250) * 200, (row - 250) * 200));
				// update pForNegativeObstacle
				_localCoordinateSys[row][col].setPForNegativeObstacle(0.3);
			}
			else
			{
				_localCoordinateSys[row][col].setPForObstacle(0.5);
			}
		}
	}
	printf("point number 0.8 is  %d\n", qt);
	return true;
}

bool ConcaveDetector::ReadDataFromShm(){
	//m_data_hdl_points.type = module::MetaData::META_LASER_HDL;
	//module::shm::SHARE_OBJECTS.GetMetaData(&m_data_hdl_points);
	//m_hdl_points = m_data_hdl_points.value.v_laserHdl;
	//m_cloud_count = m_data_hdl_points.value.v_laserHdl.pts_count;
	m_cloud_count = 1;
	for (int ii = 0; ii < m_cloud_count; ++ii){
		/*m_cloud[ii].x    = m_hdl_points.pts[ii].x;
		m_cloud[ii].y    = m_hdl_points.pts[ii].y;
		m_cloud[ii].z    = m_hdl_points.pts[ii].z;
		m_cloud[ii].dist = m_hdl_points.pts[ii].dist;
		m_cloud[ii].i    = m_hdl_points.pts[ii].i;
		m_cloud[ii].c    = m_hdl_points.pts[ii].c;
		m_cloud[ii].rot  = m_hdl_points.pts[ii].rot;*/
		m_cloud[ii].x = 0;
		m_cloud[ii].y = 1;
		m_cloud[ii].z = 1;
		m_cloud[ii].dist = 1;
		m_cloud[ii].i = 1;
		m_cloud[ii].c = 2;
		m_cloud[ii].rot = 1;
	}
	return true;
}

bool ConcaveDetector::ReadDataFromFile(){
	unsigned short rot;
	unsigned char c;

	if ((int)fread(&m_cloud_count, sizeof(int), 1, m_hdldata) < 1)
		return false;
	if ((int)fread(m_cloud_saved, sizeof(PointSave_t), m_cloud_count, m_hdldata) < m_cloud_count)
		return false;

	for (int i = 0; i < m_cloud_count; i++)
	{
		m_cloud[i].i = m_cloud_saved[i].i;
		m_cloud[i].dist = m_cloud_saved[i].dist;
		m_cloud[i].c = m_cloud_saved[i].c;
		m_cloud[i].rot = m_cloud_saved[i].rot;
		c = m_cloud[i].c;
		rot = m_cloud[i].rot;

		float cos_phi = m_cos_vert[c];
		float sin_phi = m_sin_vert[c];
		float cos_theta = m_cos_raw[rot] * m_cos_rot[c] + m_sin_raw[rot] * m_sin_rot[c];
		float sin_theta = m_sin_raw[rot] * m_cos_rot[c] - m_cos_raw[rot] * m_sin_rot[c];
		float r1 = m_cloud_saved[i].dist * 2.0f;
		float r = r1 + m_dist[c];

		float rxy = r * cos_phi;
		float xx = abs(rxy * sin_theta - m_x_off[c] * cos_theta);
		float yy = abs(rxy * cos_theta + m_x_off[c] * sin_theta);

		float rx = (m_dist[c] - m_distX[c]) * (xx / 22640.0f - 0.106007f) + m_distX[c];
		float ry = (m_dist[c] - m_distY[c]) * (yy / 23110.0f - 0.083514f) + m_distY[c];

		//x:
		r = r1 + rx;
		rxy = r * cos_phi;
		int x = (int)(rxy * sin_theta - m_x_off[c] * cos_theta);

		//y:
		r = r1 + ry;
		rxy = r * cos_phi;
		int y = (int)(rxy * cos_theta + m_x_off[c] * sin_theta);

		//z:
		r = r1 + m_dist[c];
		int z = (int)(r * sin_phi + m_z_off[c]);

		m_cloud[i].x = x;
		m_cloud[i].y = y;
		m_cloud[i].z = z;
	}

	return true;
}

CvScalar polyRansac(const vector<CvPoint3D32f>& pt) {
	if (pt.size() == 295)
	{
		cout << "" << endl;
	}

	CvMat *matA = NULL, *matB = NULL, *matX = NULL, *matX_opt = NULL;
	CvMat *matA_full = NULL, *matB_full = NULL, *matX_full = NULL, *matDiff_full = NULL;
	CvMat *matA_filtered = NULL, *matB_filtered = NULL;

	const int RANSAC_LOOP = 50;
	const float RANSAC_TOL = 0.5;
	const float RANSAC_TOL_STRICT = 0.35;
	const float RANSAC_LEAST_SIZE = 0.5;

	int counter = 0, max_counter = 0;
	int s[3];
	float x, y, a, b, c, y_min, y_max, y_cur;
	double belief;
	vector<int> filtered_index;
	CvScalar param = cvScalar(0);

	if ((int)pt.size() <= 3) //if ((int)pt.size() < 10)          // tan 20131126 if ((int)pt.size() < 10)
		return cvScalar(0);

	matA = cvCreateMat(3, 3, CV_32FC1);
	matB = cvCreateMat(3, 1, CV_32FC1);
	matX = cvCreateMat(3, 1, CV_32FC1);
	matX_opt = cvCreateMat(3, 1, CV_32FC1);
	matA_full = cvCreateMat((int)pt.size(), 3, CV_32FC1);
	matB_full = cvCreateMat((int)pt.size(), 1, CV_32FC1);
	matX_full = cvCreateMat((int)pt.size(), 1, CV_32FC1);
	matDiff_full = cvCreateMat((int)pt.size(), 1, CV_32FC1);

	for (int i = 0; i < (int)pt.size(); i++)
	{
		x = (float)pt[i].x / 1000;
		y = (float)pt[i].y / 1000;
		cvmSet(matA_full, i, 0, y * y);
		cvmSet(matA_full, i, 1, y);
		cvmSet(matA_full, i, 2, 1);
		cvmSet(matB_full, i, 0, x);
	}

	//cvSolve(matA_full, matB_full, matX_opt, CV_SVD);

	//a = cvmGet(matX_opt, 0, 0);
	//b = cvmGet(matX_opt, 1, 0);
	//c = cvmGet(matX_opt, 2, 0);

	//param = cvScalar(a, b, c, 1);

	for (int cycle_counter = 0; cycle_counter < RANSAC_LOOP; cycle_counter++)
	{
		s[0] = (int)((double)rand() / RAND_MAX * ((int)pt.size() - 1));
		do
		{
			s[1] = (int)((double)rand() / RAND_MAX * ((int)pt.size() - 1));
		} while (s[0] == s[1]);
		do
		{
			s[2] = (int)((double)rand() / RAND_MAX * ((int)pt.size() - 1));
		} while (s[2] == s[0] || s[2] == s[1]);

		for (int i = 0; i < 3; i++)
		{
			x = (float)pt[s[i]].x / 1000;
			y = (float)pt[s[i]].y / 1000;
			cvmSet(matA, i, 0, y * y);
			cvmSet(matA, i, 1, y);
			cvmSet(matA, i, 2, 1);
			cvmSet(matB, i, 0, x);
		}

		cvSolve(matA, matB, matX);
		cvGEMM(matA_full, matX, 1, matB_full, -1, matDiff_full);

		counter = 0;
		for (int i = 0; i < (int)pt.size(); i++)
		{
			if (fabs(cvmGet(matDiff_full, i, 0)) < RANSAC_TOL)
				counter++;
		}

		if (counter > max_counter)
		{
			cvCopy(matX, matX_opt);
			max_counter = counter;
			filtered_index.clear();
			for (int i = 0; i < (int)pt.size(); i++)
			{
				if (fabs(cvmGet(matDiff_full, i, 0)) < RANSAC_TOL_STRICT)
					filtered_index.push_back(i);
			}
		}
	}

	if ((int)filtered_index.size() >= 3 && (int)filtered_index.size() > (int)(RANSAC_LEAST_SIZE * max_counter))
	{
		matA_filtered = cvCreateMat((int)filtered_index.size(), 3, CV_32FC1);
		matB_filtered = cvCreateMat((int)filtered_index.size(), 1, CV_32FC1);

		y_min = y_max = pt[filtered_index[0]].y;
		for (int i = 0; i < (int)filtered_index.size(); i++)
		{
			y_cur = pt[filtered_index[i]].y;
			if (y_cur > y_max)
				y_max = y_cur;
			if (y_cur < y_min)
				y_min = y_cur;

			cvmSet(matA_filtered, i, 0, cvmGet(matA_full, filtered_index[i], 0));
			cvmSet(matA_filtered, i, 1, cvmGet(matA_full, filtered_index[i], 1));
			cvmSet(matA_filtered, i, 2, cvmGet(matA_full, filtered_index[i], 2));
			cvmSet(matB_filtered, i, 0, cvmGet(matB_full, filtered_index[i], 0));
		}
		cvSolve(matA_filtered, matB_filtered, matX_opt, CV_SVD);

		cvReleaseMat(&matA_filtered);
		cvReleaseMat(&matB_filtered);

		a = (float)cvmGet(matX_opt, 0, 0);
		b = (float)cvmGet(matX_opt, 1, 0);
		c = (float)cvmGet(matX_opt, 2, 0);
		belief = (double)filtered_index.size() / max_counter;

		//if (fabs(a) <= 0.05 && fabs(b) <= 0.5 && (y_max - y_min) > 1.0)//tan 20131126 10)
		if (1)//tian 20140809
			param = cvScalar(a, b, c, belief);
		else
		{
			param = cvScalar(0);

			//cout <<" massege 1 " << " a = " << a << " b = " << b  <<  " c = " << c <<" y_max = " << y_max<< "  y_min=" << y_min << endl;
		}
	}
	else
	{
		param = cvScalar(0);
		//cout << " message 2 " <<  "size =" << filtered_index.size() << " least " << RANSAC_LEAST_SIZE * max_counter << endl;
	}

	cvReleaseMat(&matA);
	cvReleaseMat(&matB);
	cvReleaseMat(&matX);
	cvReleaseMat(&matX_opt);
	cvReleaseMat(&matA_full);
	cvReleaseMat(&matB_full);
	cvReleaseMat(&matX_full);
	cvReleaseMat(&matDiff_full);

	return param;
}

bool ConcaveDetector::ProcessArray(){
	// 1.store origin points into two dimentional array
	int c, count[HDL_LASER_NUMBER];
	for (int i = 0; i < HDL_LASER_NUMBER; i++){
		count[i] = 0;
	}
	for (int i = 0; i < m_cloud_count; i++){
		c = m_cloud[i].c;
		m_point[c].pt[count[c]].x = m_cloud[i].x;
		m_point[c].pt[count[c]].y = m_cloud[i].y;
		m_point[c].pt[count[c]].z = m_cloud[i].z;
		m_point[c].road_type[count[c]] = 0;
		m_point[c].pt[count[c]].dist = m_cloud[i].dist;
		m_point[c].pt[count[c]].i = m_cloud[i].i;
		m_point[c].pt[count[c]].c = m_cloud[i].c;
		m_point[c].pt[count[c]].rot = 9000 - m_cloud[i].rot - int(laser_angle[c] * 100);

		if (m_point[c].pt[count[c]].rot < 0)
		{
			m_point[c].pt[count[c]].rot += 36000;
		}
		count[c]++;
	}
	// 2.update the number of points in every line
	for (int i = 0; i < HDL_LASER_NUMBER; i++)
	{
		m_point[i].pt_count = count[i];
	}

	// 3.sort the 64 lasers from near to far
	Point_laser* pl = new Point_laser[HDL_LASER_NUMBER];
	for (int i = 0; i < HDL_LASER_NUMBER; i++)
	{
		pl[i] = m_point[m_laser_index[i] - 1];
	}
	for (int i = 0; i < HDL_LASER_NUMBER; i++)
	{
		m_point[i] = pl[i];
	}
	delete[] pl;
	return true;
}

bool ConcaveDetector::LocateTargetRegionEdge(){
	int ul = 250; //  0 ~  250   unit is 200mm
	int ur = 250; //250 ~ +500   unit is 200mm
	int section = 0;
	for (int v = 250; v < 500; v+=25) {  //
		float tmpl = 0.5;
		for (int i = 0; i < 25; i++){
			tmpl = MAX( _localCoordinateSys[v+i][ul].getPForObstacle(), tmpl);
			if (tmpl == 0.8)
			{
				break;
			}
		}
		
		while (tmpl < 0.8){
			ul -= 1;
			if (ul<200)
			{
				ul = 200;
				break;
			}
			for (int i = 0; i < 25; i++){
				tmpl = MAX(_localCoordinateSys[v+i][ul].getPForObstacle(), tmpl);
				if (tmpl == 0.8)
				{
					break;
				}
			}
		}
		float tmpr = 0.5;
		for (int i = 0; i < 25; i++){
			tmpr = MAX(_localCoordinateSys[v+i][ur].getPForObstacle(), tmpr);
			if (tmpr == 0.8)
			{
				break;
			}
		}
		while (tmpr < 0.8){
			ur += 1;
			if (ur > 300)
			{
				ur = 300;
				break;
			}
			for (int i = 0; i < 25; i++){
				tmpr = MAX(_localCoordinateSys[v+i][ur].getPForObstacle(), tmpr);
				if (tmpr == 0.8)
				{
					break;
				}
			}
		}
		// unit is mm
		_leftEdgeArray[section]  = Point2f((float)(ul-250)*200, (float)section*5000);
		_rightEdgeArray[section] = Point2f((float)(ur-250)*200, (float)section*5000);
		section++;
		int mid = (ul + ur) / 2;
		ul = mid; ur = mid;
	}
	return true;
}

bool ConcaveDetector::CollectPointInbox(){
	// Init the m_point_inbox
	for (int i = 0; i < HDL_LASER_NUMBER_ROAD; i++){
		m_point_inbox[i].pt_count = 0;
	}
	// Fill the m_point_inbox
	for (int i = 0; i < HDL_LASER_NUMBER_ROAD; i++){
		int point_number_inline = m_point[i].pt_count;
		for (int j = 0; j < point_number_inline; j++){
			for (int k = 0; k < 10; k++){
				if (m_point[i].pt[j].x >= _leftEdgeArray[k].x  && \
					m_point[i].pt[j].x < _rightEdgeArray[k].x && \
					m_point[i].pt[j].y >= 5000 * k             && \
					m_point[i].pt[j].y < 5000 * (k + 1))
				{
					m_point[i].road_type[j] = 1;
					m_point_inbox[i].pt[m_point_inbox[i].pt_count++] = m_point[i].pt[j];
					break;
				}
			}
		}
	}
	return true;
}

bool ConcaveDetector::LocateFeaturePoint(){
	for (int i = 0; i < HDL_LASER_NUMBER_ROAD; i++)
	{
		Point_laser_t aLaser = m_point_inbox[i];
		vector<CvPoint3D32f> pts;
		for (int j = 0; j < aLaser.pt_count; j++){
			//pts.push_back(aLaser.pt[j]);
			CvPoint3D32f tmp;
			tmp.x = (float)aLaser.pt[j].y;
			tmp.y = (float)aLaser.pt[j].x;
			tmp.z = (float)aLaser.pt[j].z;
			pts.push_back(tmp);
		}

		CvScalar prams = polyRansac(pts); // prams used specified for unit meter

		// search for feature point 
		int dot_number = m_point_inbox[i].pt_count;
		for (int j = 0; j < dot_number; j++){
			int x = m_point_inbox[i].pt[j].x;
			int y = m_point_inbox[i].pt[j].y;
			int z = m_point_inbox[i].pt[j].z;

			double distance = (y -( prams.val[0]/1000 * x * x + prams.val[1] * x + 1000*prams.val[2]));
			if (distance >= 400 && prams.val[3] > 0.6)
			{
				int grid_row = (int)floor(y / 200)+250;
				int grid_col = (int)floor(x / 200)+250;
				// update grid's probality in local coordinate system
				m_point[i].road_type[j] = 2;// obstacle point
				_localCoordinateSys[grid_row][grid_col].setPForNegativeObstacle(0.8);
			}
		}
	}
	return true;
}

void ConcaveDetector::RunConcaveDetector() {
	int test_current_frame_number = 0;
	while (1)
	{
		if (!ReadDataFromFile()) break;
		/// 1.calculate member value according to these key value 2.sort the line
		if (!ProcessArray()) break;
		/// update grid info in local coordinate system
		if (!UpdateLocalGrids()) break;
		/// calculate the region edge
		if (!LocateTargetRegionEdge()) break;
		/// collect all points in the target region
		if (!CollectPointInbox()) break;
		/// collect all points detected as concave points in the taget region
		if (!LocateFeaturePoint()) break;

		test_current_frame_number++;
		cout << "\nCurrent Frame Number is " << test_current_frame_number << endl;
	}
}