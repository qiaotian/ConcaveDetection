/*!
* \file NegativeObstacleDetetor.h
* \brief This object is created for detect negative obstacle
* \author QiaoTian, qiaotian@me.com
* \version 1.0
* \date 2014-08-10
*/

#include "Grid.h"
#include "Header.h"
#include <opencv2/core/types_c.h>

using namespace cv;
using namespace std;

#pragma once

static double laser_angle[LASER_NUM] =
{ 
	 -7.045186,	-6.7219572,  0.42656401, 0.76617903, -6.4329958, -6.0742288,  -8.5053186, -8.0924683,
	-5.7729578, -5.3901148,  -7.8282561, -7.4140372, -2.9672921, -2.5933869,  -5.0067892,  -4.692822,
	-2.3011179,  -1.950238,  -4.3552842, -4.0174432,  -1.622618,  -1.283185,  -3.6676581,  -3.329272,
	  1.129154,	  1.503744, -0.93195403,  -0.568941,   1.761201,   2.158946, -0.27615401, 0.14548101,
	-22.557571, -22.187004,  -11.329009, -10.697071,  -21.75388, -21.226589,  -24.767878, -24.312366,
	-20.613464, -19.912579,  -23.833963, -22.995665, -16.370895, -16.003632,  -19.372372, -19.059069,
	-15.526341, -15.003131,  -18.618452, -18.207253, -14.433419,  -13.78347,  -17.592127, -17.004923,
	-10.232719,  -9.789752,   -13.37401, -12.840743, -9.3798056, -8.8431444,  -12.416959, -11.913321
};

typedef struct SLAMPointSave
{
	unsigned short dist;
	unsigned short rot;
	unsigned char i;
	unsigned char c;
}SLAMPointSave_t;

typedef struct Arc {
	int midIndex;
	int startIndex, endIndex;
	int dotCount;
}Arc_t;

typedef struct Vehicle{
	double x;
	double y;
	double theta; // 0 ---- 2*pi
}Vehicle_t;

class ConcaveDetector
{
private:
	int		m_laser_index[HDL_LASER_NUMBER];
	FILE*   m_hdldata;

	// used to caliborate the x, y, z
	float m_rot[HDL_LASER_NUMBER];   //for each laser: rot angle
	float m_vert[HDL_LASER_NUMBER];  //vertical angle correction
	float m_dist[HDL_LASER_NUMBER];  //distance system error
	float m_z_off[HDL_LASER_NUMBER]; //vertical offset
	float m_x_off[HDL_LASER_NUMBER]; //horizantal offset
	//S2 new features:
	float m_min_i[HDL_LASER_NUMBER]; //minIntensity
	float m_max_i[HDL_LASER_NUMBER]; //maxIntensity
	float m_distX[HDL_LASER_NUMBER]; //distCorrectionX
	float m_distY[HDL_LASER_NUMBER]; //distCorrectionY
	float m_f_d[HDL_LASER_NUMBER];  //focalDistance
	float m_f_s[HDL_LASER_NUMBER]; //focalSlope

	float m_cos_rot[HDL_LASER_NUMBER];
	float m_sin_rot[HDL_LASER_NUMBER];
	float m_cos_vert[HDL_LASER_NUMBER];
	float m_sin_vert[HDL_LASER_NUMBER];
	float *m_cos_raw;
	float *m_sin_raw;
	
public:
	LPoint_t      *m_cloud;						///< m_cloud: one dimentional array point array of cloud
	PointSave_t   *m_cloud_saved;				///< m_cloud_saved: save the cloud data temprarily, which should be converted to m_cloud
	Point_laser_t *m_point;						///< m_point: two dimentional array point array of cloud
	Point_laser_t *m_point_inbox;				///< m_point_inbox: store these points in box in this container

	int           m_cloud_count;							///< the number of points in all laser circle
	Grid          _localCoordinateSys[500][500];			///< local coordiante system
	Point2f       _leftEdgeArray[20];				    ///< left edge of the target region
	Point2f       _rightEdgeArray[20];				///< right edge of the target region

	///module::MetaData_t		m_data_hdl_points;
	///module::MetaLaserHdl_t	m_hdl_points;

private:
	bool load_laser_info(const char* data_path);
public:
	ConcaveDetector();
	~ConcaveDetector();
	bool Initialize(const char* hdlfilepath);
	/// brief: assign values
	/// 
	/// assign values to each gird in cooridnate system 
	void InitLocalGrids();
	/// brief: Update Grids According to "m_cloud"
	///
	/// Update the "max_height", "min_height" and "pForObstacle"
	/// prams:
	/// return:
	bool UpdateLocalGrids();
	/// brief: Get HDL Data From Shared Memory
	/// Data has been calibrated
	bool ReadDataFromShm();
	/// brief:Get HDL Data From XXXX.hdl
	/// Data including x, y and z need to be calibrated
	/// Assign Points Value to m_cloud
	bool ReadDataFromFile();
	/// brief:Transform the Physical Structure of HDL Data
	/// 
	/// 1.store cloud into 2-dimentional array m_point
	/// 2.sort the circle from near to far
	/// prams: no prams
	/// return: return true if succeed, false the versa
	bool ProcessArray();
	/// brief: Renew points in Target Region in Ideal Coordinate System
	/// 
	/// 1.Collect the Points whose "z" is "min_height"
	/// 2.Plane-fitting and Return Prams of The Plane
	/// 3.Calibrate Points
	/// 4.Update the Original Points in Ideal Coordinate System
	bool IdealizeFrame();
	bool ReadVehicleData(const char *filepath);
	///
	///
	///
	bool LocateTargetRegionEdge();
	bool CollectPointInbox();
	bool LocateFeaturePoint();				    // using ransac
	bool UpdateGlobalGrids();			// update p in global coordinate system with p in local cooridinator system
	void RunConcaveDetector();
};

